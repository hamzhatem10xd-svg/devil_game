# Devil Game

لعبة منصات ديال الفخاخ (بحال Level Devil) على Godot 4.

## الفريق
- مبرمج 1: Player (حركة، فيزياء)
- مبرمج 2: Traps (الفخاخ والأحداث)
- مبرمج 3: Levels (بناء المراحل)
- مبرمج 4: UI + Audio + Save
- الرسام: كل شي ف assets/art

## كيفاش تبدا
1. Clone للمشروع
2. افتح Godot 4 > Import > اختار project.godot
3. `git checkout -b feature/اسم-الميزة`
4. خدم، commit، push، دير Pull Request

شوف `docs/WORKFLOW.md` و `docs/FOLDERS.md`
