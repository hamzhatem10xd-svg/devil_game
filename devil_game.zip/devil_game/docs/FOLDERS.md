# فين نحط كل ملف

| النوع | المجلد | مثال |
|---|---|---|
| مشهد اللاعب | scenes/player/ | player.tscn |
| مشهد فخ | scenes/traps/ | spike.tscn, falling_block.tscn |
| ليفيل | scenes/levels/ | level_01.tscn |
| واجهة/قوائم | scenes/ui/ | main_menu.tscn, pause.tscn |
| أشياء مشتركة | scenes/common/ | door.tscn, checkpoint.tscn |
| سكريبت اللاعب | scripts/player/ | player.gd |
| سكريبت فخ | scripts/traps/ | spike.gd |
| سكريبت ليفيل | scripts/levels/ | level_base.gd |
| سكريبت UI | scripts/ui/ | main_menu.gd |
| Autoload (عام) | scripts/autoload/ | game_manager.gd, save_manager.gd |
| صور الشخصية | assets/art/player/ | player_idle.png |
| صور الفخاخ | assets/art/traps/ | spike.png |
| خلفيات | assets/art/backgrounds/ | bg_forest.png |
| Tiles | assets/art/tiles/ | ground_tiles.png |
| صور UI | assets/art/ui/ | button.png |
| موسيقى | assets/audio/music/ | menu_theme.ogg |
| مؤثرات صوت | assets/audio/sfx/ | jump.wav, death.wav |
| خطوط | assets/fonts/ | main_font.ttf |

## قواعد التسمية
- كلشي بحروف صغيرة و snake_case: `falling_block.tscn`
- السكريبت والمشهد بنفس الاسم: `spike.tscn` + `spike.gd`
- الليفيلات مرقمة: `level_01.tscn`, `level_02.tscn`
- الصور: `نوع_اسم_حالة` مثلا `player_run_01.png`
