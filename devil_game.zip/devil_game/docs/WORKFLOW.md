# طريقة الخدمة بـ Git

1. `main` = النسخة الخدامة، ما كيتخدم فيها مباشرة.
2. كل ميزة = branch: `feature/player-movement`, `art/new-traps`
3. قبل ما تبدا: `git pull origin main`
4. كل ما تكمل حاجة: commit بسطر واضح
5. دير Pull Request، واحد آخر يراجع ويدمج.

## قاعدة ذهبية
ما تخدموش جوج على نفس ملف .tscn فنفس الوقت.
الليفيلات: كل مبرمج ليفيلات ديالو.

## الرسام
كيخدم غير ف `assets/art/` (GitHub Desktop كافي).

## الاتفاق على الملكية
| المجلد | شكون |
|---|---|
| scenes/player, scripts/player | مبرمج 1 |
| scenes/traps, scripts/traps | مبرمج 2 |
| scenes/levels, scripts/levels | مبرمج 3 |
| scenes/ui, scripts/ui, scripts/autoload, assets/audio | مبرمج 4 |
| assets/art, assets/fonts | الرسام |
