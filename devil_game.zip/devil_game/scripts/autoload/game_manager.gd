extends Node
# Autoload: زيدو ف Project Settings > Globals

var current_level: int = 1
var deaths: int = 0

func restart_level() -> void:
	deaths += 1
	get_tree().reload_current_scene()

func load_level(n: int) -> void:
	current_level = n
	get_tree().change_scene_to_file("res://scenes/levels/level_%02d.tscn" % n)
